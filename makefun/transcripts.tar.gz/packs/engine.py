#!/usr/bin/env python3
"""tiny-chess-01 entry v2.1: negamax(alpha-beta)+quiescence+TT+killer heuristic."""

import os, sys, json, random, urllib.request
from collections import defaultdict

EMPTY = '.'
PV = {'p': 100, 'n': 320, 'b': 330, 'r': 500, 'q': 900, 'k': 10000}
PC = {ch: i for i, ch in enumerate(' pnbrqk PNBRQK')}
DIR = {
    'n': [-17, -15, -10, -6, 6, 10, 15, 17],
    'b': [-9, -7, 7, 9],
    'r': [-8, -1, 1, 8],
    'q': [-9, -7, 7, 9, -8, -1, 1, 8],
}
PST = {
    'P': [0,0,0,0,0,0,0,0,
          50,50,50,50,50,50,50,50,
          10,10,20,30,30,20,10,10,
          5,5,10,25,25,10,5,5,
          0,0,0,20,20,0,0,0,
          5,-5,-10,0,0,-10,-5,5,
          5,10,10,-20,-20,10,10,5,
          0,0,0,0,0,0,0,0],
    'N': [-50,-40,-30,-30,-30,-30,-40,-50,
          -40,-20,0,0,0,0,-20,-40,
          -30,0,10,15,15,10,0,-30,
          -30,5,15,20,20,15,5,-30,
          -30,0,15,20,20,15,0,-30,
          -30,5,10,15,15,10,5,-30,
          -40,-20,0,5,5,0,-20,-40,
          -50,-40,-30,-30,-30,-30,-40,-50],
    'B': [-20,-10,-10,-10,-10,-10,-10,-20,
          -10,0,0,0,0,0,0,-10,
          -10,0,5,10,10,5,0,-10,
          -10,5,5,10,10,5,5,-10,
          -10,0,10,10,10,10,0,-10,
          -10,10,10,10,10,10,10,-10,
          -10,5,0,0,0,0,5,-10,
          -20,-10,-10,-10,-10,-10,-10,-20],
    'R': [0,0,0,0,0,0,0,0,
          5,10,10,10,10,10,10,5,
          -5,0,0,0,0,0,0,-5,
          -5,0,0,0,0,0,0,-5,
          -5,0,0,0,0,0,0,-5,
          -5,0,0,0,0,0,0,-5,
          -5,0,0,0,0,0,0,-5,
          0,0,0,5,5,0,0,0],
    'Q': [-20,-10,-10,-5,-5,-10,-10,-20,
          -10,0,0,0,0,0,0,-10,
          -10,0,5,5,5,5,0,-10,
          -5,0,5,5,5,5,0,-5,
          0,0,5,5,5,5,0,-5,
          -10,5,5,5,5,5,0,-10,
          -10,0,5,0,0,0,0,-10,
          -20,-10,-10,-5,-5,-10,-10,-20],
    'K': [-30,-40,-40,-50,-50,-40,-40,-30,
          -30,-40,-40,-50,-50,-40,-40,-30,
          -30,-40,-40,-50,-50,-40,-40,-30,
          -30,-40,-40,-50,-50,-40,-40,-30,
          -20,-30,-30,-40,-40,-30,-30,-20,
          -10,-20,-20,-20,-20,-20,-20,-10,
          20,20,0,0,0,0,20,20,
          20,30,10,0,0,10,30,20],
    'k': [30,40,40,50,50,40,40,30,
          30,40,40,50,50,40,40,30,
          30,40,40,50,50,40,40,30,
          30,40,40,50,50,40,40,30,
          20,30,30,40,40,30,30,20,
          10,20,20,20,20,20,20,10,
          -20,-20,0,0,0,0,-20,-20,
          -20,-30,-10,0,0,-10,-30,-20],
}

def parse_fen(fen):
    parts = fen.split()
    bd = list(parts[0].replace('/', ''))
    turn = parts[1] if len(parts) > 1 else 'w'
    return bd, turn

def file_of(i):
    return i % 8

def rank_of(i):
    return i // 8

def attacked(bd, sq, by_white):
    r0, c0 = rank_of(sq), file_of(sq)
    opp = not by_white
    # pawns
    for dc in [-1, 1]:
        nr, nc = r0 + (-1 if by_white else 1), c0 + dc
        if 0 <= nr < 8 and 0 <= nc < 8:
            p = bd[nr * 8 + nc]
            if (by_white and p == 'P') or (not by_white and p == 'p'):
                return True
    # knights
    for d in DIR['n']:
        ni = sq + d
        if 0 <= ni < 64 and abs(rank_of(ni) - r0) <= 2 and abs(file_of(ni) - c0) <= 2:
            p = bd[ni]
            if (by_white and p == 'N') or (not by_white and p == 'n'):
                return True
    # king
    for d in [-9, -8, -7, -1, 1, 7, 8, 9]:
        ki = sq + d
        if 0 <= ki < 64 and abs(rank_of(ki) - r0) <= 1 and abs(file_of(ki) - c0) <= 1:
            p = bd[ki]
            if (by_white and p == 'K') or (not by_white and p == 'k'):
                return True
    # sliders
    for piece, dirs in [('b', DIR['b']), ('r', DIR['r'])]:
        for d in dirs:
            i = sq + d
            while 0 <= i < 64:
                r, c = rank_of(i), file_of(i)
                if abs(r - r0) > 8 or abs(c - c0) > 8:
                    break
                p = bd[i]
                if p != '.':
                    low = p.lower()
                    cap_white = by_white and p.isupper()
                    cap_black = not by_white and p.islower()
                    if (low == piece or low == 'q') and ((cap_white and p.upper() == piece.upper()) or (cap_black and p.upper() == piece.upper())):
                        return True
                    break
                i += d
    return False

def in_check(bd, white):
    kp = 'K' if white else 'k'
    try:
        ksq = bd.index(kp)
    except ValueError:
        return False
    return attacked(bd, ksq, not white)

def pseudo_moves(bd, white):
    moves = []
    for i, p in enumerate(bd):
        if p == '.':
            continue
        if white and p.islower():
            continue
        if not white and p.isupper():
            continue
        r, c = rank_of(i), file_of(i)
        low = p.lower()
        if low == 'p':
            dir_ = -1 if white else 1
            start = 1 if white else 6
            promo = 7 if white else 0
            one = i + dir_
            if 0 <= one < 64 and bd[one] == '.':
                rr = rank_of(one)
                if rr == promo:
                    for pr in ['q', 'r', 'b', 'n']:
                        moves.append((i, one, pr))
                else:
                    moves.append((i, one))
                    two = one + dir_
                    if r == start and 0 <= two < 64 and bd[two] == '.':
                        moves.append((i, two))
            for dc in [-1, 1]:
                nc = c + dc
                nt = one + dc
                if 0 <= nt < 64 and bd[nt] != '.':
                    tgt = bd[nt]
                    cap_ok = (white and tgt.isupper()) or (not white and tgt.islower())
                    if cap_ok:
                        rr = rank_of(nt)
                        if rr == promo:
                            for pr in ['q', 'r', 'b', 'n']:
                                moves.append((i, nt, pr))
                        else:
                            moves.append((i, nt))
        elif low == 'n':
            for d in DIR['n']:
                ni = i + d
                if 0 <= ni < 64 and abs(rank_of(ni)-r)<=2 and abs(file_of(ni)-c)<=2:
                    tgt = bd[ni]
                    if tgt == '.' or ((white and tgt.isupper()) or (not white and tgt.islower())):
                        moves.append((i, ni))
        elif low in 'brq':
            for d in DIR[low]:
                ni = i + d
                steps = 0
                while 0 <= ni < 64 and steps <= 7 and abs(rank_of(ni)-r) <= 8 and abs(file_of(ni)-c) <= 8:
                    tgt = bd[ni]
                    if tgt == '.':
                        moves.append((i, ni))
                    else:
                        if (white and tgt.isupper()) or (not white and tgt.islower()):
                            moves.append((i, ni))
                        break
                    ni += d
                    steps += 1
        elif low == 'k':
            for d in [-9,-8,-7,-1,1,7,8,9]:
                ni = i + d
                if 0 <= ni < 64 and abs(rank_of(ni)-r) <= 1 and abs(file_of(ni)-c) <= 1:
                    tgt = bd[ni]
                    if tgt == '.' or ((white and tgt.isupper()) or (not white and tgt.islower())):
                        moves.append((i, ni))
    return moves

def apply(bd, m):
    fr, to, promo = m[0], m[1], m[2] if len(m) > 2 else None
    nb = bd[:]
    piece = nb[fr]
    nb[to] = (promo + piece.lower()) if promo else piece
    nb[fr] = '.'
    return nb

def legal_moves(bd, white):
    out = []
    for m in pseudo_moves(bd, white):
        nb = apply(bd, m)
        if not in_check(nb, white):
            out.append(m)
    return out

# search
NEG_INF, POS_INF = -1 << 30, 1 << 30
TT = {}
KILLER = [[[] for _ in range(32)] for __ in range(2)]

def material_score(bd, white_side):
    score = 0
    for i, p in enumerate(bd):
        if p == '.':
            continue
        is_w = p.isupper()
        val = PV[p.lower()]
        if is_w == white_side:
            score += val
            pst_key = p.upper()
            pst = PST[pst_key]
            score += pst[i] if is_w else pst[63 - i]
        else:
            score -= val
            pst_key = p.upper()
            pst = PST[pst_key]
            score -= pst[63 - i] if is_w else pst[i]
    return score

def eval_fn(bd, white):
    return material_score(bd, white) if white else -material_score(bd, white)

def qsearch(bd, alpha, beta, white, depth):
    stand = eval_fn(bd, white)
    if depth <= 0:
        return stand
    if stand >= beta:
        return beta
    if stand > alpha:
        alpha = stand
    caps = [(m, eval_fn(make_move_captured(bd,m),white))
            for m in pseudo_moves(bd, white)
            if bd[m[1]] != '.']
    caps.sort(key=lambda x: -x[1])
    for m, _ in caps:
        nb = apply(bd, m)
        if in_check(nb, white):
            continue
        sc = -qsearch(nb, -beta, -alpha, not white, depth - 1)
        if sc >= beta:
            return beta
        if sc > alpha:
            alpha = sc
    return alpha

def make_move_captured(bd, m):
    return apply(bd, m)

def negamax(bd, alpha, beta, depth, white):
    key = tuple(bd)
    if key in TT and TT[key][0] >= depth:
        return TT[key][1]
    if depth == 0:
        sc = qsearch(bd, alpha, beta, white, 4)
        TT[key] = (depth, sc)
        return sc
    moves = legal_moves(bd, white)
    if not moves:
        if in_check(bd, white):
            sc = NEG_INF
        else:
            sc = 0
        TT[key] = (depth, sc)
        return sc
    def mv_score(m):
        fr, to, promo = m
        victim = bd[to]
        cap_val = PV[victim.lower()] if victim != '.' else 0
        pm = PV[promo] if promo else 0
        tt_val = TT.get(key, (0, 0))[1]
        killer_flag = any(fr==km[0] and to==km[1] for kk in KILLER[white] for km in kk)
        return cap_val * 100 + pm * 50 + (200 if tt_val else 0) + (10 if killer_flag else 0)
    moves.sort(key=mv_score, reverse=True)
    best = NEG_INF
    for m in moves:
        nb = apply(bd, m)
        sc = -negamax(nb, -beta, -alpha, depth - 1, not white)
        if sc > best:
            best = sc
            best_m = m
            if sc > alpha:
                alpha = sc
        if alpha >= beta:
            break
    TT[key] = (depth, best)
    if 'best_m' in dir() and best_m:
        ks = KILLER[white]
        pair = (best_m[0], best_m[1])
        for k in range(min(len(ks), 2)):
            lst = [pair] + list(ks[k][:19])
            KS[k] = lst[:20]
    return best

def choose(bd, white, seed_str):
    global TT, KILLER
    TT = {}
    KILLER = [[[] for _ in range(32)] for __ in range(2)]
    rng = random.Random(int(seed_str) % (2**31))
    depth = 5
    moves = legal_moves(bd, white)
    if not moves:
        return None
    best_mv = moves[0]
    for m in moves:
        nb = apply(bd, m)
        sc = -negamax(nb, NEG_INF, POS_INF, depth - 1, not white)
        if sc > 0:
            best_mv = m
            break
    return sq(best_mv[0]) + sq(best_mv[1]) + (best_mv[2] or '')

def sq(i):
    return 'abcdefgh'[i%8] + str(8 - i//8)

if __name__ == '__main__':
    env = os.environ.get('MAKEFUN_ENV_URL', 'http://localhost:8080')
    trial_seed = os.environ.get('MAKEFUN_TRIAL_SEED', 'default')
    pf = os.environ.get('MAKEFUN_PROMPT_FILE')
    if pf and os.path.exists(pf):
        with open(pf) as f:
            lines = f.read().splitlines()
        if lines:
            trial_seed = lines[0].strip() or trial_seed

    def post(path, body):
        req = urllib.request.Request(
            env + path,
            data=json.dumps(body).encode(),
            headers={'content-type': 'application/json'},
        )
        try:
            with urllib.request.urlopen(req) as res:
                return json.load(res)
        except Exception as e:
            print(f'{path}: ERR {e}', file=sys.stderr)
            sys.exit(1)

    while True:
        g = post('/game', {})
        if g['status'] == 'done':
            break
        while g['status'] == 'your_move':
            fen = g['fen']
            legal = g.get('legal_moves', [])
            bd, _ = parse_fen(fen)
            color = g.get('colour', 'white') == 'white'
            uci = choose(bd, color, trial_seed)
            chosen = uci if uci and uci in legal else (legal[0] if legal else None)
            if chosen is None:
                break
            r = post('/move', {'game': g['game'], 'move': chosen})
            g = r
        print(f"game {g.get('game','?')}: {g.get('outcome','')} {g.get('reason','')}", file=sys.stderr)
    print(f"done: wins={g.get('wins',0)} draws={g.get('draws',0)} losses={g.get('losses',0)}", file=sys.stderr)
